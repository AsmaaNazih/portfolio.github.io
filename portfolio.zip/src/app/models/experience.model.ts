export class Experience{
    constructor(
        public id:number,
        public duree:string,
        public metier:string,
        public lieu:string,
        public description:string
    ){} 
} 