export class Projet {
    constructor(
                public id:number,
                public title:string,
                public language:string[],
                public description:string,
                public image:string[] ){}
}