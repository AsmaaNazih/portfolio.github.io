export class Career{
    constructor(
        public id:number,
        public periode:string,
        public detail:string,
        public lieu:string
    ){} 
} 